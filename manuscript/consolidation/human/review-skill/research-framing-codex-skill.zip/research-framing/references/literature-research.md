# Literature Research and Gap Verification

Use when researching related papers, novelty, or limitations.

## Search protocol

1. Define the target **question independently** from the proposed technique. Capture phenomenon, outcome, regime, comparator, assumptions, and potential mechanism.
2. Find direct competitors, a core foundation, relevant survey, common baseline, and the most relevant alternative explanation.
3. Search terminology variants, including adjacent disciplines and older labels for the same phenomenon.
4. Follow citations **backward** to foundations and **forward** to follow-ups, rebuttals, revisions, and newer evidence.
5. Search adversarially for earlier versions of the proposed contribution, stronger existing results, negative evidence, and contradictory findings.
6. Re-evaluate the proposed novelty after reading the strongest sources; update the framing if needed.

Useful query patterns:

- `"[phenomenon]" [outcome] [mechanism]`
- `[research question] [alternate terminology]`
- `[closest existing approach] limitations assumptions`
- `[claimed contribution] previous result competing method`
- `[important paper title] citation follow-up replication`

Use primary papers and section/figure/theorem locations; do not treat search snippets or an abstract as verification of technical details.

## Structured literature matrix

For each reference record:

| Field | Content |
|---|---|
| Citation and link | Verified bibliographic record / DOI / paper URL |
| Version/date | Which version was examined |
| Research question | Exact question addressed |
| Result | What the authors demonstrated, at what confidence |
| Scope | Data, setting, assumptions, populations, metrics |
| Boundary | What this does not establish |
| Basis for boundary | Author statement, mathematical assumption, negative observation, or *our inference* |
| Source location | Section, paragraph, table, figure, theorem, or page |
| Relationship | Direct predecessor, competitor, foundation, extension, contradiction, method baseline |
| Effect on gap | Supports, qualifies, eliminates, or redirects the gap |
| Verification status | Verified primary, abstract-only, secondary, inferred |

## Treat author limitations as leads, not proof

When a paper says it does not analyze X, determine whether X is a simplifying assumption, missing evaluation, omitted control, measurement weakness, algorithmic barrier, or open scientific question. Then check whether later work or another community already addresses X. State the distinctions precisely:

- **Paper boundary:** “Study A did not evaluate condition R.”
- **Literature gap:** “Among papers verified through [date], R remains unresolved.”
- **Our advance:** “We evaluate R under [design] and find [bounded result].”

Only the first can be asserted merely from a single paper.

## Stress-test the gap

- Is the unknown a precise, answerable question rather than a vague area?
- Is its resolution consequential for understanding, prediction, an intervention, or a capability?
- Is it genuinely open after the closest and newest work?
- Does the proposed evidence actually address it?
- Is the difference more than jargon, a special-case parameter, or a different plot of the same result?

Stop searching pragmatically when the closest answers are understood and focused new searches no longer change positioning. Document the search scope and date; avoid unsupported claims that *no prior work exists*.
