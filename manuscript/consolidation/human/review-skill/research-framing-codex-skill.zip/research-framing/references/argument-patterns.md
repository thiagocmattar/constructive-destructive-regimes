# Argument Patterns and Writing Formulas

These patterns generalize the **argumentative organization**, not the contested technical conclusions, of the example Adam-loss-spikes paper.

## Eight argumentative moves

| Move | Example paper's role | Generic question |
|---|---|---|
| Establish phenomenon | Introduces severe loss spikes | Why does the phenomenon matter? |
| Credit existing explanations | Discusses geometry and stability research | What is already known? |
| Expose a concrete boundary | Shows spikes in fixed-curvature examples | Which case the explanation does not settle? |
| Distinguish adjacent behavior | Separates violent spikes from oscillations | What similar result might reviewers cite? |
| Reframe explanatory variable | Looks at internal optimizer state | Which overlooked distinction or variable matters? |
| State distinct advances | Mechanism, dynamics, indicators/interventions | What exactly is contributed? |
| Preview different evidence types | Quadratic analysis and network experiments | What does each form of evidence support? |
| Bound scope | States limitations for realistic settings | Where do claims stop? |

## Possible positioning relations

- **Extension:** an established result survives or fails in consequential regime R.
- **Mechanism:** evidence distinguishes explanatory mechanism M from alternative N.
- **Reconciliation:** conflicting prior findings arise from difference C.
- **Definition/measurement:** a useful distinction makes property P measurable or testable.
- **Method/capability:** a method achieves previously difficult task Q under stated constraints.
- **Boundary/negative result:** a widely assumed result fails under explicit conditions.
- **Replication:** independent evidence changes confidence in a claim.
- **Resource/benchmark:** a new asset enables a previously impractical inquiry.

## Writing templates

**Neutral result:**
> Under [conditions], we [observed/established/enabled] [result], relative to [comparator], using [evidence]. This supports [bounded conclusion].

**Consequential gap:**
> Prior work [A, B] establishes [X] under [conditions]. However, [question Q] remains unresolved in [setting], as evidenced by [boundary/source]. This matters because [consequence].

**Positioning thesis:**
> We [introduce/establish/characterize] [specific advance] to address [precise gap], showing [result] in [scope] and distinguishing it from [closest work or account].

**Contribution:**
> We [establish/characterize/distinguish/introduce/evaluate] [advance], addressing [gap] relative to [closest work]. [Evidence] supports this under [scope].

**Related work:**
> Studies of [family] demonstrate [results] under [scope]. [Closest paper] further establishes [credit]. Their findings leave [precise question] unresolved in [setting]. We [extend/test/reconcile] this work through [specific difference].

**Limitations and follow-up:**
> Our evidence establishes [X] under [S]. It does not establish [Y] because [constraint]. [Decisive experiment/derivation] would test whether [extension or alternative] holds.

**Full opening skeleton:**
> [Phenomenon] matters because [consequence]. Existing work establishes [A] and [B] under [conditions]. Yet [question] remains unresolved in [target setting], as evidenced by [boundary]. We address it by [conceptual/methodological change]. Our central result is [bounded finding], supported by [evidence]. This enables [advance], while [limitation] remains open.

## Introduction ordering

Use paragraph functions rather than rigid word counts:

1. Problem and stakes.
2. Strongest prior knowledge and its scope.
3. Concrete gap or contradiction, with a discriminating example.
4. New idea, definition, method, or explanatory variable.
5. Findings and the evidence that supports them.
6. Distinct contributions.
7. Limits and forward questions.

**Discovery order:** observation/result → literature → gap verification → positioning → writing.
**Presentation order:** stakes → prior work → unresolved question → contribution → evidence → scope.

The narrative can be written retroactively for clarity without falsely implying an exploratory hypothesis was confirmed in advance.
