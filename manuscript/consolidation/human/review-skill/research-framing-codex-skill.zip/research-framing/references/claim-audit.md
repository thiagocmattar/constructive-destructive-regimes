# Claim and Evidence Audit

For every central contribution, trace:

`Question → closest predecessor → consequential gap → specific advance → direct evidence → scope → strongest alternative → decisive test`.

If any link is missing, narrow the claim or state the missing evidence.

## Failure modes and remedies

| Failure | Detection | Remedy |
|---|---|---|
| Circular/tautological evidence | Relationship is implied by a threshold used to select the samples | Define events independently and test non-trivial predictions |
| Multiple views treated as confirmation | Plots are algebraic transforms of one observation | Describe as complementary, not independent |
| Normal dynamics relabeled a mechanism | “Decoupling” lacks a harmful-versus-harmless criterion | Operationalize and compare regimes |
| Correlation becomes causation | Different mechanisms yield the same pattern | Use interventions or predictions that distinguish alternatives |
| Frozen-time argument becomes global guarantee | Dynamics change the supposedly fixed coefficients | State approximation and analyze or test its limits |
| GD proof silently extended to Adam | Actual update is different from proved update | Prove extension or label proxy empirical |
| Retrospective detector becomes predictor | Formula contains future values | Evaluate strictly online at time of prediction, including lead time and error rates |
| Generic novelty | Closely related concept exists under another label | Reframe as a narrower extension, comparison, or robustness test |
| Weak generalization | One regime stands for every setting | Qualify scope and validate transfer |
| Universal theorem has counterexample | Permitted initialization or limiting case violates conclusion | Add justified assumptions or weaken theorem |
| Fatal missing test called future work | Core conclusion needs the omitted check | Repair current claim or perform the test |
| Unfair description of prior art | Earlier method is blamed for not studying another question | Credit its actual contributions and limits |

## Reviewer questions

1. What is the strongest predecessor on the exact question, including under other terminology?
2. What is substantively new relative to that predecessor?
3. Were the events and thresholds defined independently?
4. Could another mechanism generate the same evidence?
5. Does the formal analysis describe the actual system or a proxy?
6. Can any allowed boundary case falsify the theorem?
7. Is prediction based only on information available at prediction time?
8. Are multiple figures genuinely independent tests?
9. Is the abstract's generality justified by the data and settings?
10. Does the limitation narrow the claim rather than merely promise more experiments?

## Claim strength vocabulary

- **Introduce/propose:** newly formulated concept or method.
- **Observe:** empirical pattern in specified settings.
- **Associate:** relation without causal identification.
- **Support:** evidence consistent with interpretation, possibly non-exclusive.
- **Experimentally distinguish:** controls isolate some alternatives within a design.
- **Prove:** formal guarantee under explicit assumptions.
- **Predict:** prospective evaluation against an independently defined event and relevant baselines.
- **Generalize:** demonstrated transfer only across tested conditions.

Return one verdict per major claim: **Supported / Supported with narrower scope / Plausible but unproven / Contradicted / Cannot assess**. For weak claims state why, minimal repair, and a better formulation.
