# Research Framing Worksheet

Fill unknown fields as **Not established**. Do not demand every answer from the user before making progress.

## A. Research inventory

- Question / phenomenon:
- Work type: experiment / definition / proof / method / resource / replication / other
- Status: proposed / exploratory / completed / validated
- Exact result:
- Setting / assumptions:
- Comparator / baseline:
- Evidence and uncertainty:
- Alternative explanations:
- What is not established:

**Neutral result sentence:** Under [conditions], we [observed/established/enabled] [result], relative to [comparator], using [evidence]. This supports [bounded conclusion].

## B. Literature map

| Citation and verified link | Result | Scope | Boundary (author-stated/inferred) | Relation to this work | Source location |
|---|---|---|---|---|---|
| | | | | | |

Search date, databases, alternate terms, backward/forward citation coverage, and missing sources:

## C. Candidate gaps

| Candidate question | Closest work | Evidence unresolved | Why consequential | Verified/provisional | Proposed resolution |
|---|---|---|---|---|---|
| | | | | | |

**Selected gap statement:** Prior work [A, B] establishes [X] under [conditions]. However, [Q] remains unresolved in [setting], as shown by [evidence]. This matters because [consequence].

## D. Contribution–evidence matrix

| Contribution | Gap | Direct evidence | Strength of inference | Scope | Alternative | Next decisive test |
|---|---|---|---|---|---|---|
| | | | | | | |

## E. Positioning and narrative

- Recommended framing and why:
- One-sentence thesis:
- Polished positioning paragraph (100–180 words):
- Introduction outline: stakes → known work → gap → conceptual change → evidence → contributions → limitations.
- Related-work families:
- Distinct, bounded contribution statements:

## F. Limits, future work, audit

| Present limitation | Consequence for claim | Specific next experiment, proof, or comparison |
|---|---|---|
| | | |

- Strongest reviewer objection:
- Repair to central claim:
- Source/uncertainty note:
